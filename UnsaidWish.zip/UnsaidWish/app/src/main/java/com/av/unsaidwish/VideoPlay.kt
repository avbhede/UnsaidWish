package com.av.unsaidwish


import android.net.Uri
import android.os.Bundle
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class VideoPlay : AppCompatActivity() {

    lateinit var mvideoView:VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_view)

        mvideoView = findViewById(R.id.video_view)

        var videoUrl:Uri=Uri.parse(intent.getStringExtra("video_url"))
        mvideoView.setVideoURI(videoUrl)
        mvideoView.start()


    }
}
