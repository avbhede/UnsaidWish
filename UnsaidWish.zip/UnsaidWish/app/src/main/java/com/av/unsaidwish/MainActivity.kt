package com.av.unsaidwish

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val bottomNavigation: BottomNavigationView = findViewById(R.id.navigation)

        val mOnNavigationItemSelectedListener =
                BottomNavigationView.OnNavigationItemSelectedListener { item ->
                    when (item.itemId) {

                        R.id.navigation_home -> {

                            val fm = supportFragmentManager
                            val fragment = Camera()
                            fm.beginTransaction().add(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().replace(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().addToBackStack(null)

                            return@OnNavigationItemSelectedListener true
                            finish()

                        }

                        R.id.navigation_wish -> {

                            val fm = supportFragmentManager
                            val fragment = Camera()
                            fm.beginTransaction().add(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().replace(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().addToBackStack(null)


                            return@OnNavigationItemSelectedListener true
                            finish()


                        }
                        R.id.navigation_camera -> {

                            val fm = supportFragmentManager
                            val fragment = Camera()
                            fm.beginTransaction().add(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().replace(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().addToBackStack(null)


                            return@OnNavigationItemSelectedListener true
                            finish()
                        }

                        R.id.navigation_inbox -> {

                            val fm = supportFragmentManager
                            val fragment = Camera()
                            fm.beginTransaction().add(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().replace(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().addToBackStack(null)


                            return@OnNavigationItemSelectedListener true
                            finish()

                        }

                        R.id.navigation_profile -> {

                            val fm = supportFragmentManager
                            val fragment = Camera()
                            fm.beginTransaction().add(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().replace(R.id.maincontent, fragment).commit()
                            fm.beginTransaction().addToBackStack(null)


                            return@OnNavigationItemSelectedListener true
                            finish()

                        }

                    }
                    false
                }


        bottomNavigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)


    }

}
