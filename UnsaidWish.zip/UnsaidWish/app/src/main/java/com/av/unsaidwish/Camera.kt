package com.av.unsaidwish

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment

/**
 * A simple [Fragment] subclass.
 */
class Camera : Fragment() {

    companion object {
        private const val VIDEO_REQUEST = 101
    }

    lateinit var videoUrl:Uri
    lateinit var play_video:Button

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        var rootview= inflater.inflate(R.layout.fragment_camera, container, false)


        play_video = rootview.findViewById(R.id.play_video)

        val videoIntent = Intent(MediaStore.ACTION_VIDEO_CAPTURE)
        startActivityForResult(videoIntent, VIDEO_REQUEST)

        play_video.setOnClickListener {

            var intent= Intent(activity,VideoPlay::class.java)
            intent.putExtra("video_url",videoUrl)
            startActivity(intent)

        }

        return rootview

     }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VIDEO_REQUEST && RESULT_OK == resultCode) {

            videoUrl = data!!.data
        }
    }

}
